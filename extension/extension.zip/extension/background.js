/**
 * Secure Vault - background.js
 * Handles IndexedDB, X25519 Key Agreement, and AES-GCM Encryption.
 */

let keyPair = null;

/* ================= IndexedDB Storage ================= */
function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open("SecureFSDB", 1);
        req.onupgradeneeded = () => req.result.createObjectStore("keys");
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

async function storeKeyPair(jwkPair) {
    const db = await openDB();
    const tx = db.transaction("keys", "readwrite");
    await tx.objectStore("keys").put(jwkPair, "pair");
}

async function loadKeyPair() {
    const db = await openDB();
    return new Promise((resolve) => {
        const req = db.transaction("keys").objectStore("keys").get("pair");
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
    });
}

/* ================= Stack-Safe Crypto Helpers ================= */

/**
 * Converts Uint8Array to Base64 string using a loop.
 * Avoids "Maximum call stack size exceeded" on large files.
 */
const bytesToB64 = (uint8Array) => {
    let binary = "";
    const len = uint8Array.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(uint8Array[i]);
    }
    return btoa(binary);
};

/**
 * Converts Base64 string to Uint8Array using a loop.
 * Ensures the output is exactly what SubtleCrypto expects.
 */
const b64ToBytes = (base64) => {
    const cleanB64 = base64.replace(/\s/g, ''); // Remove potential whitespace
    const binaryString = atob(cleanB64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
};

/* ================= Key Generation ================= */

async function generateKeyPair(forceNew = false) {
    if (!keyPair || forceNew) {
        const stored = await loadKeyPair();
        if (stored && !forceNew) {
            keyPair = {
                privateKey: await crypto.subtle.importKey("jwk", stored.private, { name: "X25519" }, false, ["deriveKey"]),
                publicKey: await crypto.subtle.importKey("jwk", stored.public, { name: "X25519" }, true, [])
            };
        } else {
            const generated = await crypto.subtle.generateKey({ name: "X25519" }, true, ["deriveKey"]);
            const jwkPrivate = await crypto.subtle.exportKey("jwk", generated.privateKey);
            const jwkPublic = await crypto.subtle.exportKey("jwk", generated.publicKey);
            await storeKeyPair({ private: jwkPrivate, public: jwkPublic });
            keyPair = generated;
        }
    }
    // Export public key as raw 32-bytes for the database
    const pubRaw = await crypto.subtle.exportKey("raw", keyPair.publicKey);
    return bytesToB64(new Uint8Array(pubRaw));
}

/* ================= Cryptography Core ================= */

async function encryptForStorage(plaintextB64, recipientPublicKeyB64) {
    const plaintextBytes = b64ToBytes(plaintextB64);
    const recipientKeyBytes = b64ToBytes(recipientPublicKeyB64);

    // X25519 Validation: Must be 32 bytes (256 bits)
    if (recipientKeyBytes.byteLength !== 32) {
        throw new Error(`Invalid Key Length: Expected 32 bytes, got ${recipientKeyBytes.byteLength}. Try re-syncing keys in the popup.`);
    }

    const recipientKey = await crypto.subtle.importKey(
        "raw", recipientKeyBytes, { name: "X25519" }, false, []
    );
    
    // Create ephemeral key for this specific transaction
    const ephemeralKey = await crypto.subtle.generateKey({ name: "X25519" }, true, ["deriveKey"]);
    
    // Derive AES-GCM 256 key via Diffie-Hellman
    const sharedSecret = await crypto.subtle.deriveKey(
        { name: "X25519", public: recipientKey },
        ephemeralKey.privateKey,
        { name: "AES-GCM", length: 256 },
        false, ["encrypt"]
    );

    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv },
        sharedSecret,
        plaintextBytes 
    );

    const ephemeralPubRaw = await crypto.subtle.exportKey("raw", ephemeralKey.publicKey);

    return {
        senderPublicKey: bytesToB64(new Uint8Array(ephemeralPubRaw)),
        iv: bytesToB64(iv),
        ciphertext: bytesToB64(new Uint8Array(ciphertext))
    };
}

async function decryptFile(payload) {
    if (!keyPair) await generateKeyPair();
    
    const senderKey = await crypto.subtle.importKey(
        "raw", b64ToBytes(payload.senderPublicKey), { name: "X25519" }, false, []
    );

    const aesKey = await crypto.subtle.deriveKey(
        { name: "X25519", public: senderKey },
        keyPair.privateKey,
        { name: "AES-GCM", length: 256 },
        false, ["decrypt"]
    );

    const plaintext = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: b64ToBytes(payload.iv) },
        aesKey,
        b64ToBytes(payload.ciphertext)
    );

    return new Uint8Array(plaintext);
}

/* ================= Message Handling ================= */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Handling encryption requests from Content Script
    if (msg.type === "ENCRYPT_FILE_REQUEST") {
        encryptForStorage(msg.plaintextB64, msg.recipientPublicKey)
            .then(payload => sendResponse({ encryptedPayload: payload }))
            .catch(err => sendResponse({ error: err.message }));
        return true; // Keep channel open for async response
    }

    // Handling key initialization from Popup
    if (msg.type === "INIT_KEYS") {
        generateKeyPair(msg.forceNew)
            .then(pub => sendResponse({ publicKey: pub }))
            .catch(err => sendResponse({ error: err.message }));
        return true; 
    }

    // Handling decryption requests from Popup
    if (msg.type === "DECRYPT_FILE") {
        decryptFile(msg.payload)
            .then(pt => {
                const b64 = bytesToB64(pt);
                sendResponse({ plaintextB64: b64 });
            })
            .catch(e => sendResponse({ error: e.message }));
        return true;
    }
});