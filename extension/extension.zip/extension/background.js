let keyPair = null;

/* ================= IndexedDB ================= */
function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open("SecureFSDB", 1);
        req.onupgradeneeded = () => req.result.createObjectStore("keys");
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

async function storeKeyPair(jwkPair) {
    const db = await openDB();
    const tx = db.transaction("keys", "readwrite");
    await tx.objectStore("keys").put(jwkPair, "pair");
}

async function loadKeyPair() {
    const db = await openDB();
    return new Promise((resolve) => {
        const req = db.transaction("keys").objectStore("keys").get("pair");
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
    });
}

/* ================= Crypto Helpers ================= */
const b64ToBytes = (b64) => Uint8Array.from(atob(b64), c => c.charCodeAt(0));
const bytesToB64 = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes)));

async function generateKeyPair(forceNew = false) {
    if (!keyPair || forceNew) {
        const stored = await loadKeyPair();
        if (stored && !forceNew) {
            keyPair = {
                privateKey: await crypto.subtle.importKey("jwk", stored.private, { name: "X25519" }, false, ["deriveKey"]),
                publicKey: await crypto.subtle.importKey("jwk", stored.public, { name: "X25519" }, true, [])
            };
        } else {
            const generated = await crypto.subtle.generateKey({ name: "X25519" }, true, ["deriveKey"]);
            const jwkPrivate = await crypto.subtle.exportKey("jwk", generated.privateKey);
            const jwkPublic = await crypto.subtle.exportKey("jwk", generated.publicKey);
            await storeKeyPair({ private: jwkPrivate, public: jwkPublic });
            keyPair = generated;
        }
    }
    const pubRaw = await crypto.subtle.exportKey("raw", keyPair.publicKey);
    return bytesToB64(pubRaw);
}

async function encryptForStorage(plaintextBytes, recipientPublicKeyB64) {
    const recipientKey = await crypto.subtle.importKey(
        "raw", 
        b64ToBytes(recipientPublicKeyB64), 
        { name: "X25519" }, 
        false, 
        []
    );
    
    const ephemeralKey = await crypto.subtle.generateKey({ name: "X25519" }, true, ["deriveKey"]);
    
    const sharedSecret = await crypto.subtle.deriveKey(
        { name: "X25519", public: recipientKey },
        ephemeralKey.privateKey,
        { name: "AES-GCM", length: 256 },
        false, ["encrypt"]
    );

    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv },
        sharedSecret,
        new Uint8Array(plaintextBytes)
    );

    const pubRaw = await crypto.subtle.exportKey("raw", ephemeralKey.publicKey);

    return {
        senderPublicKey: bytesToB64(pubRaw),
        iv: bytesToB64(iv),
        ciphertext: bytesToB64(ciphertext)
    };
}

async function decryptFile(payload) {
    if (!keyPair) await generateKeyPair();
    
    const senderKey = await crypto.subtle.importKey(
        "raw", b64ToBytes(payload.senderPublicKey), 
        { name: "X25519" }, false, []
    );

    const aesKey = await crypto.subtle.deriveKey(
        { name: "X25519", public: senderKey },
        keyPair.privateKey,
        { name: "AES-GCM", length: 256 },
        false, ["decrypt"]
    );

    const plaintext = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: b64ToBytes(payload.iv) },
        aesKey,
        b64ToBytes(payload.ciphertext)
    );

    return new Uint8Array(plaintext);
}

/* ================= Message Listeners ================= */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "ENCRYPT_FILE_REQUEST") {
      // We call the async function
      encryptForStorage(msg.plaintext, msg.recipientPublicKey)
          .then(payload => {
              console.log("Encryption complete, sending response...");
              sendResponse({ encryptedPayload: payload });
          })
          .catch(err => {
              console.error("Encryption failed:", err);
              sendResponse({ error: err.message });
          });
      
      // CRITICAL: This 'return true' tells Chrome to keep the 
      // message channel open until sendResponse is called above.
      return true; 
  }

  if (msg.type === "INIT_KEYS") {
      generateKeyPair(msg.forceNew).then(pub => sendResponse({ publicKey: pub }));
      return true; 
  }

  if (msg.type === "DECRYPT_FILE") {
      decryptFile(msg.payload)
          .then(pt => sendResponse({ plaintext: Array.from(pt) }))
          .catch(e => sendResponse({ error: e.message }));
      return true;
  }
});