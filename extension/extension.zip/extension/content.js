// content.js
console.log("Vault Bridge Active");

window.addEventListener("VAULT_ENCRYPT_REQUEST", (event) => {

    const { plaintextB64, recipientPublicKey } = event.detail;

    // Safety check updated for Base64 strings
    if (!plaintextB64 || !recipientPublicKey) {
        window.dispatchEvent(new CustomEvent("VAULT_ENCRYPT_RESPONSE", {
            detail: { error: "Content script received incomplete data (B64 missing)." }
        }));
        return;
    }

    chrome.runtime.sendMessage({
        type: "ENCRYPT_FILE_REQUEST",
        plaintextB64: plaintextB64, // Forward the string
        recipientPublicKey: recipientPublicKey
    }, (response) => {
        if (chrome.runtime.lastError) {
            window.dispatchEvent(new CustomEvent("VAULT_ENCRYPT_RESPONSE", {
                detail: { error: "Extension background unreachable." }
            }));
            return;
        }

        window.dispatchEvent(new CustomEvent("VAULT_ENCRYPT_RESPONSE", {
            detail: response
        }));
    });
});