// content.js
console.log("Vault Bridge Active ✅");

// Listen for the "SHOUT" from main.js
window.addEventListener("VAULT_ENCRYPT_REQUEST", (event) => {
    const { plaintext, recipientPublicKey } = event.detail;

    // Safety check: Ensure we have data before bothering the background
    if (!plaintext || !recipientPublicKey) {
        window.dispatchEvent(new CustomEvent("VAULT_ENCRYPT_RESPONSE", {
            detail: { error: "Content script received incomplete data." }
        }));
        return;
    }

    // Forward to background.js
    chrome.runtime.sendMessage({
        type: "ENCRYPT_FILE_REQUEST",
        plaintext: plaintext,
        recipientPublicKey: recipientPublicKey
    }, (response) => {
        // Handle cases where background script is unavailable or crashes
        if (chrome.runtime.lastError) {
            window.dispatchEvent(new CustomEvent("VAULT_ENCRYPT_RESPONSE", {
                detail: { error: "Extension background unreachable: " + chrome.runtime.lastError.message }
            }));
            return;
        }

        // Send the result (success or error) back to main.js
        window.dispatchEvent(new CustomEvent("VAULT_ENCRYPT_RESPONSE", {
            detail: response
        }));
    });
});

// Keep your existing public key listener
window.addEventListener("message", async (event) => {
    if (event.data.type === "REQUEST_PUBLIC_KEY") {
        chrome.runtime.sendMessage({ type: "INIT_KEYS" }, (response) => {
            window.postMessage({
                type: "PUBLIC_KEY",
                key: response ? response.publicKey : null
            }, "*");
        });
    }
});