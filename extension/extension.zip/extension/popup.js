const SERVER_URL = "http://localhost:5000";

/* ================= Stack-Safe Helpers ================= */

/**
 * Converts a Base64 string to a Uint8Array without using the spread operator.
 * This prevents "Maximum call stack size exceeded" on large file downloads.
 */
const b64ToBytes = (base64) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
};

/* ================= Initialization Logic ================= */

async function checkAuth() {
    try {
        const res = await fetch(`${SERVER_URL}/api/me`, {
            method: "GET",
            credentials: "include" 
        });

        if (res.ok) {
            const data = await res.json();
            if (data.authenticated) {
                showVault(data.username);
                return;
            }
        }
    } catch (e) {
        console.log("Not logged in or server down.");
    }
    document.getElementById("login-section").style.display = "block";
    document.getElementById("vault-section").style.display = "none";
}

checkAuth();

function showVault(username) {
    document.getElementById("login-section").style.display = "none";
    document.getElementById("vault-section").style.display = "block";
    document.getElementById("status-bar").innerText = `Authenticated as ${username}`;
}

/* ================= Event Listeners ================= */

// --- Login Logic ---
document.getElementById("login-btn").onclick = async () => {
    const username = document.getElementById("user").value;
    const password = document.getElementById("pass").value;

    try {
        const res = await fetch(`${SERVER_URL}/api/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password }),
            credentials: "include"
        });

        if (res.ok) {
            showVault(username); 
        } else {
            const data = await res.json();
            alert(data.message || "Login failed");
        }
    } catch (e) {
        alert("Server unreachable.");
    }
};

// --- Logout Logic ---
document.getElementById("logout-btn").onclick = async () => {
    try {
        const res = await fetch(`${SERVER_URL}/api/logout`, {
            method: "POST",
            credentials: "include"
        });

        if (res.ok) {
            document.getElementById("login-section").style.display = "block";
            document.getElementById("vault-section").style.display = "none";
            document.getElementById("status-bar").innerText = "Logged out successfully.";
            document.getElementById("user").value = "";
            document.getElementById("pass").value = "";
        }
    } catch (e) {
        alert("Logout failed: Server unreachable.");
    }
};

// --- Key Sync Logic ---
document.getElementById("gen").onclick = () => {
    chrome.runtime.sendMessage({ type: "INIT_KEYS", forceNew: false }, async (res) => {
        if (!res || res.error) return alert("Key init failed: " + (res?.error || "Unknown error"));

        try {
            const response = await fetch(`${SERVER_URL}/public-key`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include", 
                body: JSON.stringify({ publicKey: res.publicKey })
            });

            if (response.ok) {
                alert("Public key linked to your account! ✅");
            } else {
                alert("Sync failed: Are you logged in?");
            }
        } catch (e) {
            alert("Server error during sync.");
        }
    });
};

// --- Decryption Logic ---
document.getElementById("decrypt").onclick = async () => {
    const fileInput = document.getElementById("file");
    if (!fileInput.files.length) return alert("Please select an encrypted .json file first.");

    const file = fileInput.files[0];
    const fileText = await file.text();
    
    let encrypted;
    try {
        encrypted = JSON.parse(fileText);
    } catch (e) {
        return alert("File is not a valid JSON encrypted payload.");
    }

    if (!encrypted.senderPublicKey || !encrypted.iv || !encrypted.ciphertext) {
        return alert("Invalid file format. This is not a Secure Vault encrypted file.");
    }

    // UI state: Start processing
    const decryptBtn = document.getElementById("decrypt");
    const originalBtnText = decryptBtn.innerText;
    decryptBtn.innerText = "Decrypting...";
    decryptBtn.disabled = true;

    chrome.runtime.sendMessage({ type: "DECRYPT_FILE", payload: encrypted }, (res) => {
        // Reset UI state
        decryptBtn.innerText = originalBtnText;
        decryptBtn.disabled = false;

        if (chrome.runtime.lastError) {
            return alert("Extension error: " + chrome.runtime.lastError.message);
        }

        if (res.error) {
            console.error("Decryption error:", res.error);
            return alert("Decryption failed: " + res.error);
        }

        if (res.plaintextB64) {
            try {
                // Stack-safe conversion
                const byteArray = b64ToBytes(res.plaintextB64); 
                const blob = new Blob([byteArray], { type: "application/octet-stream" });
                const url = URL.createObjectURL(blob);
                
                // Use the original filename if stored in the JSON, otherwise fallback
                const fileName = encrypted.originalName || "decrypted_file.dat";

                chrome.downloads.download({
                    url: url,
                    filename: fileName,
                    saveAs: true
                }, () => {
                    // Cleanup the URL to free memory after a short delay
                    setTimeout(() => URL.revokeObjectURL(url), 1000);
                });
            } catch (e) {
                console.error("Download processing error:", e);
                alert("Download processing failed. The file might be too large for browser memory.");
            }
        } else {
            alert("Received empty data from the decryption service.");
        }
    });
};