const SERVER_URL = "http://localhost:5000";

// --- Initialization Logic ---
async function checkAuth() {
    try {
        const res = await fetch(`${SERVER_URL}/api/me`, {
            method: "GET",
            credentials: "include" // This sends the cookie to the server
        });

        if (res.ok) {
            const data = await res.json();
            if (data.authenticated) {
                showVault(data.username);
                return;
            }
        }
    } catch (e) {
        console.log("Not logged in or server down.");
    }
    // If we reach here, show login (default)
    document.getElementById("login-section").style.display = "block";
    document.getElementById("vault-section").style.display = "none";
}

// Call checkAuth immediately on popup open
checkAuth();

// --- UI Toggle Helper ---
function showVault(username) {
    // Force the display styles
    document.getElementById("login-section").style.display = "none";
    document.getElementById("vault-section").style.display = "block";
    document.getElementById("status-bar").innerText = `Authenticated as ${username}`;
}

// Login Function
document.getElementById("login-btn").onclick = async () => {
    const username = document.getElementById("user").value;
    const password = document.getElementById("pass").value;

    try {
        const res = await fetch(`${SERVER_URL}/api/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password }),
            credentials: "include" // Important to save the session cookie
        });

        const data = await res.json();
        if (res.ok) {
            // IMMEDIATELY update the UI without needing to reopen
            showVault(username); 
        } else {
            alert(data.message || "Login failed");
        }
    } catch (e) {
        alert("Server unreachable.");
    }
};

// --- Logout Logic ---
document.getElementById("logout-btn").onclick = async () => {
    try {
        const res = await fetch(`${SERVER_URL}/api/logout`, {
            method: "POST",
            credentials: "include" // Ensures the server knows WHICH session to kill
        });

        if (res.ok) {
            // Reset UI back to login state
            document.getElementById("login-section").style.display = "block";
            document.getElementById("vault-section").style.display = "none";
            document.getElementById("status-bar").innerText = "Logged out successfully.";
            
            // Clear inputs
            document.getElementById("user").value = "";
            document.getElementById("pass").value = "";
        }
    } catch (e) {
        alert("Logout failed: Server unreachable.");
    }
};

// Key Sync Function (Only works if logged in)
document.getElementById("gen").onclick = () => {
  chrome.runtime.sendMessage({ type: "INIT_KEYS", forceNew: false }, async (res) => {
    if (!res || res.error) return alert("Key init failed");

    try {
      const response = await fetch(`${SERVER_URL}/public-key`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // IMPORTANT: include credentials to send the Flask session cookie
        credentials: "include", 
        body: JSON.stringify({ publicKey: res.publicKey })
      });

      if (response.ok) {
        alert("Public key linked to your account! ");
      } else {
        alert("Sync failed: Are you logged in?");
      }
    } catch (e) {
      alert("Server error during sync.");
    }
  });
};

document.getElementById("decrypt").onclick = async () => {
    const fileInput = document.getElementById("file");
    if (!fileInput.files.length) return alert("Please select an encrypted .json file first.");

    const file = fileInput.files[0];
    const fileText = await file.text();
    
    let encrypted;
    try {
        encrypted = JSON.parse(fileText);
    } catch (e) {
        return alert("File is not a valid JSON encrypted payload.");
    }

    // Validation: Ensure the JSON structure is correct
    if (!encrypted.senderPublicKey || !encrypted.iv || !encrypted.ciphertext) {
        return alert("Invalid file format. This is not a Secure Vault encrypted file.");
    }

    // Inform the user processing has started
    const originalBtnText = document.getElementById("decrypt").innerText;
    document.getElementById("decrypt").innerText = "Decrypting...";
    document.getElementById("decrypt").disabled = true;

    chrome.runtime.sendMessage({ type: "DECRYPT_FILE", payload: encrypted }, (res) => {
        // Reset Button
        document.getElementById("decrypt").innerText = originalBtnText;
        document.getElementById("decrypt").disabled = false;

        if (chrome.runtime.lastError) {
            return alert("Extension error: " + chrome.runtime.lastError.message);
        }

        if (res.error) {
            return alert("Decryption failed: " + res.error);
        }

        // --- FIX FOR 0-BYTE ISSUE ---
        if (!res.plaintext || res.plaintext.length === 0) {
            return alert("Error: Decrypted data is empty.");
        }

        try {
            // Reconstruct the Uint8Array from the standard Array sent by background
            const byteArray = new Uint8Array(res.plaintext);
            
            // Create the Blob with the correct binary data
            const blob = new Blob([byteArray], { type: "application/octet-stream" });
            
            // Generate a temporary download URL
            const url = URL.createObjectURL(blob);
            
            // Trigger the native Chrome download manager
            chrome.downloads.download({
                url: url,
                filename: "decrypted_output.dat", // Suggests a generic extension
                saveAs: true
            }, () => {
                // Cleanup memory
                setTimeout(() => URL.revokeObjectURL(url), 1000);
            });
        } catch (e) {
            console.error("Download Error:", e);
            alert("Failed to process decrypted file.");
        }
    });
};